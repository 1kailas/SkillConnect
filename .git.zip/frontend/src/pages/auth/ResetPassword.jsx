const ResetPassword = () => {
  return <div>Reset Password Page</div>;
};

export default ResetPassword;
