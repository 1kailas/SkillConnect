const ForgotPassword = () => {
  return <div>Forgot Password Page</div>;
};

export default ForgotPassword;
