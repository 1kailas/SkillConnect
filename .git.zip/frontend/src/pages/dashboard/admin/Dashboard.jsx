const Dashboard = () => <div>Admin Dashboard</div>;
export default Dashboard;
