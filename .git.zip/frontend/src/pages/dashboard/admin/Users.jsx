const Users = () => <div>Manage Users</div>;
export default Users;
