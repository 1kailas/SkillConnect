const Settings = () => <div>Admin Settings</div>;
export default Settings;
