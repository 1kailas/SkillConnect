const Jobs = () => <div>Manage Jobs</div>;
export default Jobs;
