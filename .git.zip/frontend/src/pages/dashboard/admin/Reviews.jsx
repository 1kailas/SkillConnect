const Reviews = () => <div>Manage Reviews</div>;
export default Reviews;
