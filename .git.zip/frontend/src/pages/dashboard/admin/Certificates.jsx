const Certificates = () => <div>Verify Certificates</div>;
export default Certificates;
